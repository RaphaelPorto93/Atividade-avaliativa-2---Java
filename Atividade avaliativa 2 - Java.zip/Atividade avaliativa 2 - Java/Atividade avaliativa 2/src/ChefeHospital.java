import java.util.ArrayList;
import java.util.List;


public class ChefeHospital {
    private static ArrayList <Funcionario> funcionario = new ArrayList<>();
    
    public static void cadastrarFuncionario(Funcionario funcionario) {
        funcionario.add(funcionario);
        System.out.println("Funcionário cadastrado com sucesso.");
    }

    public static Funcionario buscar (String matricula) {
        for (Funcionario funcionario : funcionario){
            return funcionario;
        }
    }
    return null;
}


public static void excluirFuncionario(String matricula) {
    Funcionario funcionario = buscar (matricula);
    if (funcionario != null){
        funcionario.remove(funcionario);
        System.out.println("Funcionário removido com sucesso.");
    } else {
        System.out.println("Funcionárionão encontrado.");
    } 
}

public static void listarFuncionario() {
    if (funcionario.isEmpty()) {
        System.out.println("Nenhum funcionário cadastrado.");
    } else {
        for (Funcionario funcionario : funcionario){ 
            System.out.println(funcionario);
        }
    }
}

public static void excluirTodosFuncionarios() {
    funcionario.clear();
    System.out.println("Todos os funcionários foram excluídos.");
}

