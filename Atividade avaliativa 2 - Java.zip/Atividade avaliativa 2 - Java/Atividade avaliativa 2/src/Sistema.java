import java.util.Scanner;

public class Sistema {
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int opcao;

        do {
            System.out.println("\nMENU");
            System.out.println("1) Cadastrar funcionário");
            System.out.println("2) Buscar funcionário");
            System.out.println("3) Excluir funcionário");
            System.out.println("4) Listar funcionários");
            System.out.println("5) Excluir funcionários");
            System.out.println("0) Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    cadastrarFuncionario(scanner);
                    break;
                
                case 2:
                    buscarFuncionario(scanner);
                    break;

                case 3:
                    excluirFuncionario(scanner);
                    break;

                case 4:
                    listarFuncionario(scanner);
                    break;

                case 5:
                    excluirFuncionario(scanner);
                    break;

                case 0:
                    System.out.println("Saindo.");
                    break;
            
                default:
                    System.out.println("Opção inválida.");
                    break;
            }
        } while (opcao != 0);
    }

    public static void cadastrarFuncionario (Scanner scanner) {
        System.out.println("\nCadastro de funcionário");
        System.out.println("Nome: ");
        String nome = scanner.nextLine();
        System.out.println("Matrícula: ");
        String matricula = scanner.nextLine();

        System.out.println("Escolha o tipo de funcionário:");
        System.out.println("1- Médifo");
        System.out.println("2- Enfermeiro");
        System.out.println("Administração");
        System.out.print("Opção: ");
        int tipo = scanner.nextInt();
        scanner.nextLine();

        Funcionario funcionario;

        switch (tipo) {
            case 1:
                System.out.println("Especialidade: ");
                String especialidade = scanner.nextLine();
                funcionario = new Medico(nome, matricula, especialidade);
                break;

            case 2:
                System.out.println("Setor: ");
                String setor = scanner.nextLine();
                funcionario = new Enfermeiro(nome, matricula, setor);
                break;

            case 3:
                System.out.println("Setor: ");
                String setorAdm = scanner.nextLine();
                funcionario = new Adm(nome, matricula, setorAdm);
                break;
        
            default:
                System.out.println("Opção inválida");
                return;
        }

        ChefeHospital.cadastrarFuncionario(funcionario);
    }

    public static void buscarFuncionario(Scanner scanner) {
        System.out.println("\nBusca de funcionário");
        System.out.println("Matrícula do funcionário: ");
        String matricula = scanner.nextLine();

        Funcionario funcionario = ChefeHospital.buscarFuncionario(matricula);

        if (funcionario != null) {
            System.out.println("Funcionário encontrado: ");
            System.out.println(funcionario);
        } else {
            System.out.println("Funcionário não encontrado.");
        }
    }

    public static void excluirFuncionario(Scanner scanner) {
        System.out.println("Excluir funcionário");
        System.out.println("Matrícula do funcionário: ");
        String matricula = scanner.nextLine();

        ChefeHospital.excluirFuncionario(matricula);
    }

    public static void listarFuncionario() {
        System.out.println("Lista dos funcionários");
        ChefeHospital.listarFuncionario();
    }

    public static void excluirFuncionario() {
        System.out.println("Excluir todos os funcionários");
        ChefeHospital.excluirTodosFuncionarios();
    }

    public static void executar() {

        int op;
        do {

            Sistema();
            op = Console.lerInt();
            opcao(op);

        } while (op != 0);

    }
}

