public class Medico extends Funcionario {
    private String especialidade;

    public Medico(String nome, String matricula, String especialidade) {
        super(nome, matricula);
        this.especialidade = especialidade;
    }

    @Override
    public String toString() {
        return super.toString() + ", Especialidade: " + especialidade;
    }
    
}
