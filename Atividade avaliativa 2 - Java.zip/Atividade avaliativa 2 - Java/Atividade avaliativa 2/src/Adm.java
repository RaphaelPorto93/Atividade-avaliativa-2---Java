public class Adm extends Funcionario {
    private String setorAdm;

    public Adm(String nome, String matricula, String setorAdm){
        super(nome, matricula);
        this.setorAdm = setorAdm;
    }

    @Override
    public String toString() {
        return super.toString() + ", Setor: " + setorAdm;
    }
    
}
