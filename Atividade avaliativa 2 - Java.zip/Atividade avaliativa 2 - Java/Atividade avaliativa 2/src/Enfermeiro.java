public class Enfermeiro extends Funcionario {
    private String setor;

    public Enfermeiro(String nome, String matricula, String setor){
        super(nome, matricula);
        this.setor = setor;
    }

    @Override
    public String toString() {
        return super.toString() + ", Setor: " + setor;
    }
    
}
